﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AnnouncementApp.Migrations
{
    public partial class RecreateDatabase : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
          

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
